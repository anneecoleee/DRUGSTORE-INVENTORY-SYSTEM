-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: finalproj
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `Employee_ID` int(11) NOT NULL,
  `Employee_Name` varchar(30) DEFAULT NULL,
  `Employee_Phone_Number` int(15) DEFAULT NULL,
  `Employee_Address` varchar(30) DEFAULT NULL,
  `Employee_Email` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Employee_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (123,'Ann Luyao',924357,'Cugman, CDOC','annloraine14@gmail.com'),(124,'Neil Abad',24656,'Tagoloan, CDOC','neilabad@gmail.com'),(125,'Mariz Gabales',46893,'Pabayo, CDOC','marizgabales@gmail.com'),(126,'Arbie Delizo',35657,'Westwoods, CDOC','arboedelizo@gmail.com');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `Product_ID` int(11) NOT NULL,
  `Product_Name` varchar(45) DEFAULT NULL,
  `Category` varchar(45) DEFAULT NULL,
  `Selling_Price` double DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Generic_Name` varchar(45) DEFAULT NULL,
  `Manufactured_Date` date DEFAULT NULL,
  `Expiration_Date` date DEFAULT NULL,
  `Manufacturer` varchar(45) DEFAULT NULL,
  `Supplier_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`Product_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (101,'Biogesic','Fever',10.25,50,'Paracetamol','2018-04-06','2020-05-07','Unilab Inc.',201),(102,'Neozep','Clogged Nose',7.35,80,'Phenylephrine','2019-05-17','2021-08-28','Unilab Inc.',202),(103,'Buscopan','Dysmenorrhea',12.5,79,'Scopolamine Butylbromide','2019-06-04','2022-06-19','Unilab Inc.',203),(104,'Mefenamic','Dysmenorrhea',8.75,48,'Ponstel','2019-03-04','2023-05-04','Unilab Inc.',204),(105,'Bioflu','Clogged Nose',7.85,123,'Phenylephrine','2016-06-04','2018-04-19','Unilab Inc.',205),(106,'Advil','Pain Reliever',23.5,567,'Ibuprofen','2019-08-05','2018-05-06','Unilab Inc.',206),(107,'Strepsils','Soarthroat',47,89,'Dextrometrophan','2016-08-05','2018-06-06','Unilab Inc.',207);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stocks`
--

DROP TABLE IF EXISTS `stocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stocks` (
  `Stock_ID` int(11) NOT NULL,
  `Product_ID` int(11) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`Stock_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stocks`
--

LOCK TABLES `stocks` WRITE;
/*!40000 ALTER TABLE `stocks` DISABLE KEYS */;
INSERT INTO `stocks` VALUES (123,456,3),(456,103,90),(789,106,90),(21124,3535,NULL);
/*!40000 ALTER TABLE `stocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier` (
  `Supplier_ID` int(11) NOT NULL,
  `Supplier_Name` varchar(45) DEFAULT NULL,
  `Supplier_Email` varchar(45) DEFAULT NULL,
  `Supplier_Phone_Number` int(11) DEFAULT NULL,
  `Supplier_Address` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Supplier_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (201,'AbadMed','abadmed@gmail.com',92345,'Tagoloan, CDOC'),(202,'AbadMed','abadmed@gmail.com',9237,'Tagoloan, CDOC'),(203,'AbadMed','abadmed@gmail.com',3485,'Tagoloan, CDOC'),(204,'MarizMed','marizmed@gmail.com',9346,'Pabayp, CDOC'),(205,'MarizMed','marizmed@gmail.com',9237,'Pabayo, CDOC'),(206,'MarizMed','marizmed@gmail.com',31959,'Pabayo, CDOC');
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-07 22:27:53
