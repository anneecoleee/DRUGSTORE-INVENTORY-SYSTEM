package Bresa;

import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class UpdateSP extends JFrame {
	
	Connection conn = null;
	/**
	 * 
	 */
	PreparedStatement stat = null;
	ResultSet rs = null;

	private JPanel contentPane;
	private JTextField txtID;
	private JTextField txtSP;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
///					UpdateSP frame = new UpdateSP();
//					frame.setVisible(true);
	///			} catch (Exception e) {
	//				e.printStackTrace();
	///			}
		//	}
	//	});
//	}

	/**
	 * Create the frame.
	 */
	public UpdateSP() {
		setBounds(100, 100, 275, 291);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtID = new JTextField();
		txtID.setBounds(43, 71, 147, 20);
		contentPane.add(txtID);
		txtID.setColumns(10);
		
		txtSP = new JTextField();
		txtSP.setColumns(10);
		txtSP.setBounds(43, 145, 147, 20);
		contentPane.add(txtSP);
		
		JLabel lblNewLabel = new JLabel("Enter Product ID\r\n\r\n");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(43, 50, 134, 17);
		contentPane.add(lblNewLabel);
		
		JLabel lblSellingPrice = new JLabel("New Product's Selling Price\r\n\r\n");
		lblSellingPrice.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblSellingPrice.setBounds(43, 125, 197, 17);
		contentPane.add(lblSellingPrice);
		
		JButton btnNewButton = new JButton("UPDATE\r\n");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					String sql = "Update products SET Selling_Price=? WHERE Product_ID=?";
						
				conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
                stat = conn.prepareStatement(sql);
			
					stat.setString(2,txtID.getText());
					stat.setString(1,txtSP.getText());
					
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Updated Successfully :) ");		
					
				}catch(SQLException	| HeadlessException ex) {
					
					JOptionPane.showMessageDialog(null, ex);
					
					
				}
				
				dispose();
			}
		});
		btnNewButton.setBounds(72, 176, 89, 23);
		contentPane.add(btnNewButton);
	}

}
