package Bresa;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class AddnewStock extends JFrame {
	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;

	private JPanel contentPane;
	private JTextField PID;
	private JTextField stID;
	private JTextField Quant1;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
	///			try {
	//				AddnewStock frame = new AddnewStock();
	//				frame.setVisible(true);
	//			} catch (Exception e) {
	///				e.printStackTrace();
	//			}
	//		}
	//	});
//	}

	/**
	 * Create the frame.
	 */
	public AddnewStock() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 431, 356);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ADD NEW STOCK");
		lblNewLabel.setBounds(158, 11, 104, 46);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Stock ID");
		lblNewLabel_1.setBounds(61, 67, 66, 32);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblProductId = new JLabel("Product ID");
		lblProductId.setBounds(61, 127, 72, 32);
		contentPane.add(lblProductId);
		
		stID = new JTextField();
		stID.setBounds(137, 73, 125, 20);
		contentPane.add(stID);
		stID.setColumns(10);
		
		PID = new JTextField();
		PID.setColumns(10);
		PID.setBounds(137, 133, 125, 20);
		contentPane.add(PID);
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
try {
					
					String sql = "Insert into Stocks" + "(Stock_ID,Product_ID,Quantity)" 
									+ "values (?,?,?)";
					conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
					stat = conn.prepareStatement(sql);
					stat.setString(1,stID.getText());
					stat.setString(2,PID.getText()); 
					stat.setString(3, Quant1.getText());
					
				
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "New Stock Added");	
					dispose();
					
					
					
					
				}catch(SQLException	| HeadlessException ex) {
					
					JOptionPane.showMessageDialog(null, ex);
							
				}
			}
		});
		btnNewButton.setBounds(146, 250, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel Quant = new JLabel("Quantity");
		Quant.setBounds(55, 181, 72, 32);
		contentPane.add(Quant);
		
		Quant1 = new JTextField();
		Quant1.setColumns(10);
		Quant1.setBounds(137, 187, 125, 20);
		contentPane.add(Quant1);
	}
}
