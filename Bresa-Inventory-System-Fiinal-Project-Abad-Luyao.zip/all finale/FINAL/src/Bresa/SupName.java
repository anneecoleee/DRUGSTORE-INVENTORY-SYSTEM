package Bresa;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class SupName extends JFrame {

	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	private JPanel contentPane;
	private JTextField txtSID;
	private JTextField txtName;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					SupName frame = new SupName();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SupName() {
		setBounds(100, 100, 282, 294);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEnterSupplierId = new JLabel("Enter Supplier ID\r\n\r\n");
		lblEnterSupplierId.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblEnterSupplierId.setBounds(39, 55, 134, 17);
		contentPane.add(lblEnterSupplierId);
		
		txtSID = new JTextField();
		txtSID.setColumns(10);
		txtSID.setBounds(39, 79, 147, 20);
		contentPane.add(txtSID);
		
		JLabel lblNewSupplierName = new JLabel("New Supplier Name\r\n\r\n");
		lblNewSupplierName.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewSupplierName.setBounds(39, 125, 197, 17);
		contentPane.add(lblNewSupplierName);
		
		txtName = new JTextField();
		txtName.setColumns(10);
		txtName.setBounds(39, 144, 147, 20);
		contentPane.add(txtName);
		
		JButton button = new JButton("UPDATE\r\n");
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					String sql = "Update supplier SET Supplier_Name=? WHERE Supplier_ID=?";
						
					conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
					stat = conn.prepareStatement(sql);
			
					stat.setString(2,txtSID.getText());
					stat.setString(1,txtName.getText());
					
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Updated Successfully :) ");		
					
				}catch(SQLException	| HeadlessException ex) {
					
					JOptionPane.showMessageDialog(null, ex);
					
					
				}
			dispose();
			}
		});
		button.setBounds(68, 175, 89, 23);
		contentPane.add(button);
	}

}
