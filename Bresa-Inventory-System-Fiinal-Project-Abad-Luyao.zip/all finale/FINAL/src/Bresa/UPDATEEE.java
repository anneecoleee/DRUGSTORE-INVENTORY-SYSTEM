package Bresa;



import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class UPDATEEE extends JFrame {

	
	Connection conn = null;
	PreparedStatement stat = null;  
	ResultSet rs = null;
	
	private JPanel contentPane;
	
	

	/**
	 * Create the frame.
	 */
	public UPDATEEE() {
		setBackground(Color.MAGENTA);
		setBounds(100, 100, 1070, 465);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUpdateAProduct = new JLabel("\"UPDATE A PRODUCT\"");
		lblUpdateAProduct.setFont(new Font("SimSun", Font.BOLD, 19));
		lblUpdateAProduct.setBounds(441, 5, 274, 72);
		contentPane.add(lblUpdateAProduct);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(205, 133, 63));
		panel.setBounds(34, 88, 1010, 257);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnUpdateTheProduct = new JButton("UPDATE THE PRODUCT NAME\r\n\r\n");
		btnUpdateTheProduct.setBounds(10, 89, 209, 23);
		panel.add(btnUpdateTheProduct);
		
		JButton btnUpdateCategory = new JButton("UPDATE CATEGORY");
		btnUpdateCategory.setBounds(10, 147, 209, 23);
		panel.add(btnUpdateCategory);
		
		JButton btnUpdateSellingPrice = new JButton("UPDATE SELLING PRICE\r\n\r\n");
		btnUpdateSellingPrice.setBounds(767, 147, 229, 23);
		panel.add(btnUpdateSellingPrice);
		
		JButton btnUpdateQuantity = new JButton("UPDATE QUANTITY");
		btnUpdateQuantity.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				UpdateQuantity frame = new UpdateQuantity();
				frame.setVisible(true);
			}
		});
		btnUpdateQuantity.setBounds(255, 89, 229, 23);
		panel.add(btnUpdateQuantity);
		
		JButton btnUpdateGenericName = new JButton("UPDATE GENERIC NAME");
		btnUpdateGenericName.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				UpdateGenericName frame = new UpdateGenericName();
				frame.setVisible(true);
			}
		});
		btnUpdateGenericName.setBounds(255, 147, 229, 23);
		panel.add(btnUpdateGenericName);
		
		JButton btnUpdateManufacturedDate = new JButton("UPDATE MANUFACTURED DATE");
		btnUpdateManufacturedDate.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				UpdateManuDate frame = new UpdateManuDate();
				frame.setVisible(true);
			}
		});
		btnUpdateManufacturedDate.setBounds(767, 89, 229, 23);
		panel.add(btnUpdateManufacturedDate);
		
		JButton btnUpdateManufacturer = new JButton("UPDATE MANUFACTURER");
		btnUpdateManufacturer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				UpdateManufacturer frame = new UpdateManufacturer();
				frame.setVisible(true);
			}
		});
		btnUpdateManufacturer.setBounds(534, 147, 209, 23);
		panel.add(btnUpdateManufacturer);
		
		JButton btnUpdateExpirationDate = new JButton("UPDATE EXPIRATION DATE");
		btnUpdateExpirationDate.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				UpdateExpirationDate frame = new UpdateExpirationDate();
				frame.setVisible(true);
			}
		});
		btnUpdateExpirationDate.setBounds(534, 89, 209, 23);
		panel.add(btnUpdateExpirationDate);
		
		JLabel lblChooseWhatTo = new JLabel("CHOOSE WHAT TO UPDATE");
		lblChooseWhatTo.setBounds(393, 11, 247, 72);
		panel.add(lblChooseWhatTo);
		lblChooseWhatTo.setFont(new Font("Microsoft YaHei UI Light", Font.BOLD, 16));
		btnUpdateSellingPrice.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				UpdateSP frame = new UpdateSP();
				frame.setVisible(true);
			}
		});
		btnUpdateCategory.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				UpdateCat frame = new UpdateCat();
				frame.setVisible(true);
			}
		});
		btnUpdateTheProduct.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				UpdateName frame = new UpdateName();
				frame.setVisible(true);
			}
		});
	}
}
