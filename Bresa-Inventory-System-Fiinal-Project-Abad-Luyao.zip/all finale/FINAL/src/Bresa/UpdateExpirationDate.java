package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class UpdateExpirationDate extends JFrame {

	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
		
	private JPanel contentPane;
	private JTextField txtED;
	private JTextField txtID;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					UpdateExpirationDate frame = new UpdateExpirationDate();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public UpdateExpirationDate() {
		setBackground(Color.GREEN);
		setBounds(100, 100, 294, 286);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("Enter Product ID\r\n\r\n");
		label.setFont(new Font("Tahoma", Font.BOLD, 12));
		label.setBounds(27, 41, 134, 17);
		contentPane.add(label);
		
		JLabel lblNewProductsExpiration = new JLabel("New Product's Expiration Date\r\n\r\n");
		lblNewProductsExpiration.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewProductsExpiration.setBounds(27, 111, 232, 17);
		contentPane.add(lblNewProductsExpiration);
		
		txtID = new JTextField();
		txtID.setColumns(10);
		txtID.setBounds(27, 59, 147, 20);
		contentPane.add(txtID);
		
		txtED = new JTextField();
		txtED.setColumns(10);
		txtED.setBounds(27, 130, 147, 20);
		contentPane.add(txtED);
		
		JButton button = new JButton("UPDATE\r\n");
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					String sql = "Update products SET Manufactured_Date=? WHERE Product_ID=?";
						
				conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
                stat = conn.prepareStatement(sql);
			
					stat.setString(2,txtID.getText());
					stat.setString(1,txtED.getText());
					
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Updated Successfully :) ");		
					
				}catch(SQLException	| HeadlessException ex) {
					
					JOptionPane.showMessageDialog(null, ex);
					
					
				}
				
				dispose();
				
					
			}
			
			
		});
		button.setBounds(55, 161, 89, 23);
		contentPane.add(button);
	}

}
