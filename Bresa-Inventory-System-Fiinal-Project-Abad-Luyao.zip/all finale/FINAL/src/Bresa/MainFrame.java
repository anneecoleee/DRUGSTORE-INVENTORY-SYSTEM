package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainFrame extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
///				try {
//					MainFrame frame = new MainFrame();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
	//			}
	//		}
	//	});
	//}

	/**
	 * Create the frame.
	 */
	public MainFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 440, 356);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("Bresa Drug Store Inventory System");
		label.setFont(new Font("SimSun", Font.BOLD, 20));
		label.setBounds(25, 30, 380, 37);
		contentPane.add(label);
		
		JButton btnNewButton = new JButton("VIEW PRODUCT'S AND SUPPLlER'S INFORMATION");
		btnNewButton.setBackground(new Color(222, 184, 135));
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				Opening frame = new Opening();
				frame.setVisible(true);
				frame.ProdTables();
				frame.SuppTables();
				dispose();
			}
		});
		btnNewButton.setBounds(51, 111, 342, 37);
		contentPane.add(btnNewButton);
		
		JButton btnViewSupplyStocks = new JButton("VIEW SUPPLY STOCKS AND EMPLOYEEE INFORMATION");
		btnViewSupplyStocks.setBackground(new Color(222, 184, 135));
		btnViewSupplyStocks.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				EmpSTocks frame = new EmpSTocks();
				frame.setVisible(true);
				frame.EmployeeTable();
				frame.StockTable();
				
				dispose();
				
			}
		});
		btnViewSupplyStocks.setBounds(51, 187, 342, 37);
		contentPane.add(btnViewSupplyStocks);
		
		JButton btnLogout = new JButton("LOGOUT");
		btnLogout.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(EXIT_ON_CLOSE);
				
			}
		});
		btnLogout.setBounds(176, 254, 89, 23);
		contentPane.add(btnLogout);
	}

}
