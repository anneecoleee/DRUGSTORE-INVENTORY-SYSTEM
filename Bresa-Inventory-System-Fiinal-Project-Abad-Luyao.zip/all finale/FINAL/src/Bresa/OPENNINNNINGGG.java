package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class OPENNINNNINGGG extends JFrame  {
	
	
	
	/**
	 * 
	 */
	
	Connection conn = null;
	PreparedStatement stat = null;  
	ResultSet rs = null;
	
	private JPanel contentPane;
	private JTextField txtName;
	private JTextField txtCat;
	private JTextField txtSP;
	private JTextField txtQ;
	private JTextField txtGName;
	private JTextField txtMD;
	private JTextField txtED;
	private JTextField txtMan;
	private JTextField txtID;
	private JTextField txtSID;

	/**
	 * Launch the application.
	 */
	
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					OPENNINNNINGGG frame = new OPENNINNNINGGG();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
	///	});
//	}

	/**
	 * Create the frame.
	 */
	

	
	
	public OPENNINNNINGGG() {
	
		setBounds(100, 100, 409, 444);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAddAProduct = new JLabel("ADD A PRODUCT");
		lblAddAProduct.setFont(new Font("SimSun", Font.BOLD, 18));
		lblAddAProduct.setBounds(122, 11, 207, 78);
		contentPane.add(lblAddAProduct);
		
		JLabel lblProductId = new JLabel("Product ID");
		lblProductId.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblProductId.setBounds(43, 86, 113, 14);
		contentPane.add(lblProductId);
		
		JLabel lblProductName = new JLabel("Product Name");
		lblProductName.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblProductName.setBounds(43, 111, 113, 14);
		contentPane.add(lblProductName);
		
		JLabel lblCategory = new JLabel("Category");
		lblCategory.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblCategory.setBounds(43, 136, 113, 20);
		contentPane.add(lblCategory);
		
		JLabel lblSellingPrice = new JLabel("Selling Price");
		lblSellingPrice.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblSellingPrice.setBounds(43, 161, 113, 20);
		contentPane.add(lblSellingPrice);
		
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblQuantity.setBounds(43, 186, 113, 20);
		contentPane.add(lblQuantity);
		
		JLabel lblGenericName = new JLabel("Generic Name");
		lblGenericName.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblGenericName.setBounds(43, 211, 113, 14);
		contentPane.add(lblGenericName);
		
		JLabel lblManufacturedDate = new JLabel("Manufactured Date");
		lblManufacturedDate.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblManufacturedDate.setBounds(43, 236, 143, 14);
		contentPane.add(lblManufacturedDate);
		
		JLabel lblExpirationDate = new JLabel("Expiration Date");
		lblExpirationDate.setForeground(Color.BLACK);
		lblExpirationDate.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblExpirationDate.setBounds(42, 261, 127, 19);
		contentPane.add(lblExpirationDate);
		
		JLabel lblManafucturer = new JLabel("Manafucturer");
		lblManafucturer.setForeground(Color.BLACK);
		lblManafucturer.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblManafucturer.setBounds(43, 286, 127, 14);
		contentPane.add(lblManafucturer);
		
		txtName = new JTextField();
		txtName.setColumns(10);
		txtName.setBounds(188, 111, 148, 20);
		contentPane.add(txtName);
		
		txtCat = new JTextField();
		txtCat.setColumns(10);
		txtCat.setBounds(188, 136, 148, 20);
		contentPane.add(txtCat);
		
		txtSP = new JTextField();
		txtSP.setColumns(10);
		txtSP.setBounds(188, 161, 148, 20);
		contentPane.add(txtSP);
		
		txtQ = new JTextField();
		txtQ.setColumns(10);
		txtQ.setBounds(188, 186, 148, 20);
		contentPane.add(txtQ);
		
		txtGName = new JTextField();
		txtGName.setColumns(10);
		txtGName.setBounds(188, 211, 148, 20);
		contentPane.add(txtGName);
		
		txtMD = new JTextField();
		txtMD.setColumns(10);
		txtMD.setBounds(188, 236, 148, 20);
		contentPane.add(txtMD);
		
		txtED = new JTextField();
		txtED.setColumns(10);
		txtED.setBounds(188, 263, 148, 19);
		contentPane.add(txtED);
		
		txtMan = new JTextField();
		txtMan.setColumns(10);
		txtMan.setBounds(188, 286, 148, 20);
		contentPane.add(txtMan);
		
		JButton btnNewButton = new JButton("ADD THE PRODUCT\r\n");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				try {
						
					String sql = "Insert into products" + "(Product_ID,Product_Name,Category,Selling_Price,Quantity,Generic_Name,Manufactured_Date,Expiration_Date,Manufacturer,Supplier_ID)" 
									+ "values (?,?,?,?,?,?,?,?,?,?)";
					conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
					stat = conn.prepareStatement(sql);
					stat.setString(1,txtID.getText());
					stat.setString(2,txtName.getText()); 
					stat.setString(3,txtCat.getText());
					stat.setString(4,txtSP.getText());
					stat.setString(5,txtQ.getText());
					stat.setString(6,txtGName.getText());
					stat.setString(7,txtMD.getText());
					stat.setString(8,txtED.getText());
					stat.setString(9,txtMan.getText());
					stat.setString(10, txtSID.getText());
					
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Product Added");
					dispose();
					
					
				}catch(SQLException	| HeadlessException ex) {
					
					JOptionPane.showMessageDialog(null, ex);
							
				}
				
				Opening Frame1 = new Opening();
				Frame1.ProdTables();
				
			
				
			}
		});
		btnNewButton.setBounds(188, 346, 144, 31);
		contentPane.add(btnNewButton);
		
		txtID = new JTextField();
		txtID.setColumns(10);
		txtID.setBounds(188, 86, 148, 20);
		contentPane.add(txtID);
		
		JLabel lblNewLabel = new JLabel("Supplier ID");
		lblNewLabel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
		lblNewLabel.setBounds(43, 311, 107, 22);
		contentPane.add(lblNewLabel);
		
		txtSID = new JTextField();
		txtSID.setBounds(188, 315, 148, 20);
		contentPane.add(txtSID);
		txtSID.setColumns(10);
	}
}
