package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class EmpSTocks extends JFrame {

	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;
	
	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	private JTextField txtSearch;
	private JTextField stocks;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
	//				EmpSTocks frame = new EmpSTocks();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
	public void EmSearchTables() {
		
		try {
			
			
			conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
			String sql = "Select *from employee WHERE Employee_ID=?";
			stat = conn.prepareStatement(sql);
			stat.setString(1,txtSearch.getText());	
			rs = stat.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));

			
					
		}catch(Exception ex) {
		 	
			JOptionPane.showMessageDialog(null, ex);		
		}
	}
public void EmployeeTable() {
		
		try {
			
			 conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
			String sql = "Select *from employee";
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
	
		}catch(Exception ex) {
		 	
			JOptionPane.showMessageDialog(null, ex);		
		}
}
	
public void StockTable() {
	
	try {
		
		 conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
		String sql = "Select *from Stocks";
		stat = conn.prepareStatement(sql);
		rs = stat.executeQuery();
		table_1.setModel(DbUtils.resultSetToTableModel(rs));

	}catch(Exception ex) {
	 	
		JOptionPane.showMessageDialog(null, ex);		
	}
}

public void stockSearchTables() {
	
	try {
		
		
		conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
		String sql = "Select *from Stocks WHERE Stock_ID=?";
		stat = conn.prepareStatement(sql);
		stat.setString(1,stocks.getText());	
		rs = stat.executeQuery();
		table_1.setModel(DbUtils.resultSetToTableModel(rs));

		
				
	}catch(Exception ex) {
	 	
		JOptionPane.showMessageDialog(null, ex);		
	}
}
		
	/**
	 * Create the frame.
	 */
	public EmpSTocks() {

		setBounds(100, 100, 779, 498);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\"WELCOME TO BRESA DRUG STORE INVENTORY SYSTEM\"");
		label.setFont(new Font("SimSun", Font.BOLD, 19));
		label.setBounds(86, 38, 520, 20);
		contentPane.add(label);
		
		JButton button = new JButton("Back to Options");
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				MainFrame frame = new MainFrame();
				frame.setVisible(true);
				dispose();
			}
		});
		button.setBounds(10, 7, 127, 20);
		contentPane.add(button);
		
		JLabel lblEmployeesInformation = new JLabel("EMPLOYEE'S INFORMATION");
		lblEmployeesInformation.setFont(new Font("SimSun", Font.BOLD, 20));
		lblEmployeesInformation.setBackground(Color.GREEN);
		lblEmployeesInformation.setBounds(10, 69, 281, 34);
		contentPane.add(lblEmployeesInformation);
		
		JLabel lblStocksInformation = new JLabel("STOCK'S INFORMATION");
		lblStocksInformation.setFont(new Font("SimSun", Font.BOLD, 20));
		lblStocksInformation.setBackground(Color.GREEN);
		lblStocksInformation.setBounds(10, 268, 281, 34);
		contentPane.add(lblStocksInformation);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 114, 720, 96);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
			},
			new String[] {
				"Employee_ID", "Employee_Name", "Employee_Phone_Number", "Employee_Address", "Employee_Email"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, Object.class, String.class, String.class
			};
			@Override
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 303, 720, 104);
		contentPane.add(scrollPane_1);
		
		table_1 = new JTable();
		scrollPane_1.setViewportView(table_1);
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
			},
			new String[] {
				"Stock_ID", "Product_ID", "Quantity"
			}
		));
		
		JButton btnAddAnEmployee = new JButton("ADD AN EMPLOYEE");
		btnAddAnEmployee.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				EmployeeForm frame = new EmployeeForm();
				frame.setVisible(true);
			}
		});
		btnAddAnEmployee.setBounds(20, 214, 148, 23);
		contentPane.add(btnAddAnEmployee);
		
		JButton btnRemoveAnEmployee = new JButton("REMOVE AN EMPLOYEE\r\n");
		btnRemoveAnEmployee.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				RemoveEmployee frame = new RemoveEmployee();
				frame.setVisible(true);
				
			}
		});
		btnRemoveAnEmployee.setBounds(178, 214, 167, 23);
		contentPane.add(btnRemoveAnEmployee);
		
		JButton btnUpdateAnEmployee = new JButton("UPDATE AN EMPLOYEE");
		btnUpdateAnEmployee.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				UpdateEmployee frame = new UpdateEmployee();
				frame.setVisible(true);
			}
		});
		btnUpdateAnEmployee.setBounds(355, 215, 175, 23);
		contentPane.add(btnUpdateAnEmployee);
		
		JButton btnRefreshTable = new JButton("REFRESH TABLE");
		btnRefreshTable.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				EmployeeTable();
			}
		});
		btnRefreshTable.setBounds(540, 215, 132, 23);
		contentPane.add(btnRefreshTable);
		
		JButton btnSearch = new JButton("Search Employee");
		btnSearch.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				EmSearchTables();
			}
		});
		btnSearch.setBounds(591, 78, 139, 23);
		contentPane.add(btnSearch);
		
		txtSearch = new JTextField();
		txtSearch.setText("Enter Employee ID");
		txtSearch.setColumns(10);
		txtSearch.setBounds(454, 79, 127, 20);
		contentPane.add(txtSearch);
		
		JButton btnNewButton = new JButton("ADD NEW STOCK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AddnewStock frame = new AddnewStock();
				frame.setVisible(true);
				StockTable();
			}
			
			
			
			
		});
		btnNewButton.setBounds(86, 418, 163, 23);
		contentPane.add(btnNewButton);
		
		JButton btnUpdateStockQuantity = new JButton("UPDATE STOCK QUANTITY");
		btnUpdateStockQuantity.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StockUpQuan frame = new StockUpQuan();
				frame.setVisible(true);
			}
			
		});
		btnUpdateStockQuantity.setBounds(259, 418, 182, 23);
		contentPane.add(btnUpdateStockQuantity);
		
		JButton button_1 = new JButton("REFRESH TABLE");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StockTable();
			}
		});
		button_1.setBounds(451, 418, 132, 23);
		contentPane.add(button_1);
		
		stocks = new JTextField();
		stocks.setText("Enter Stock ID");
		stocks.setColumns(10);
		stocks.setBounds(454, 278, 127, 20);
		contentPane.add(stocks);
		
		JButton btnSearchStock = new JButton("Search Stock");
		btnSearchStock.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				stockSearchTables();
			}
		});
		btnSearchStock.setBounds(591, 277, 139, 23);
		contentPane.add(btnSearchStock);
	}
}
