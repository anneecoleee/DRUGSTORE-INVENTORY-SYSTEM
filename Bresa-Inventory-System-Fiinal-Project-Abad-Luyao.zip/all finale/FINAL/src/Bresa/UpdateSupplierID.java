package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class UpdateSupplierID extends JFrame {
	
	Connection conn = null;
	PreparedStatement stat = null;
	ResultSet rs = null;

	private JPanel contentPane;
	private JTextField txtID;
	private JTextField txtSup;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					UpdateSupplierID frame = new UpdateSupplierID();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
	///			}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public UpdateSupplierID() {
		
		setBounds(100, 100, 289, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("Enter Product ID\r\n\r\n");
		label.setFont(new Font("Tahoma", Font.BOLD, 12));
		label.setBounds(45, 64, 134, 17);
		contentPane.add(label);
		
		txtID = new JTextField();
		txtID.setColumns(10);
		txtID.setBounds(45, 83, 147, 20);
		contentPane.add(txtID);
		
		JLabel lblNewProductsSupplier = new JLabel("New Product's Supplier ID");
		lblNewProductsSupplier.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewProductsSupplier.setBounds(45, 130, 232, 17);
		contentPane.add(lblNewProductsSupplier);
		
		txtSup = new JTextField();
		txtSup.setColumns(10);
		txtSup.setBounds(45, 151, 147, 20);
		contentPane.add(txtSup);
		
		JButton button = new JButton("UPDATE\r\n");
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					String sql = "Update products SET Supplier_ID=? WHERE Product_ID=?";
						
				conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
                stat = conn.prepareStatement(sql);
			
					stat.setString(2,txtID.getText());
					stat.setString(1,txtSup.getText());
					
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Updated Successfully :) ");		
					
				}catch(SQLException	| HeadlessException ex) {
					
					JOptionPane.showMessageDialog(null, ex);
					
					
				}
				
				dispose();
				
			}
			
		});
		button.setBounds(70, 196, 89, 23);
		contentPane.add(button);
	}

}
