package Bresa;

import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class UpdateCat extends JFrame {

	
	Connection conn = null;
	/**
	 * 
	 */
	PreparedStatement stat = null;
	ResultSet rs = null;
	
	private JPanel contentPane;
	private JTextField txtID;
	private JTextField txtCat;
	private JButton btnNewButton;
	private JLabel lblEnterProductId;
	private JLabel lblNewProductCategory;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
///					UpdateCat frame = new UpdateCat();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
///			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public UpdateCat() {
		
		setBounds(100, 100, 274, 277);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtID = new JTextField();
		txtID.setBounds(34, 66, 130, 20);
		contentPane.add(txtID);
		txtID.setColumns(10);
		
		txtCat = new JTextField();
		txtCat.setBounds(34, 141, 130, 20);
		contentPane.add(txtCat);
		txtCat.setColumns(10);
		
		JLabel label = new JLabel("New label");
		label.setBounds(34, 125, 46, -23);
		contentPane.add(label);
		
		btnNewButton = new JButton("UPDATE\r\n");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					String sql = "Update products SET Category=? WHERE Product_ID=?";
						
				conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj","root","boboka");
                stat = conn.prepareStatement(sql);
			
					stat.setString(2,txtID.getText());
					stat.setString(1,txtCat.getText());
					
					stat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Updated Successfully :) ");		
					
				}catch(SQLException	| HeadlessException ex) {
					
					JOptionPane.showMessageDialog(null, ex);
					
					
				}
			
				dispose();
			}
		});
		btnNewButton.setBounds(44, 172, 89, 23);
		contentPane.add(btnNewButton);
		
		lblEnterProductId = new JLabel("Enter Product ID\r\n");
		lblEnterProductId.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblEnterProductId.setBounds(34, 38, 130, 23);
		contentPane.add(lblEnterProductId);
		
		lblNewProductCategory = new JLabel("New Product Category");
		lblNewProductCategory.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewProductCategory.setBounds(34, 113, 160, 23);
		contentPane.add(lblNewProductCategory);
	}

}
