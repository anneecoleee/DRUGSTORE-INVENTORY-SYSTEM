package Bresa;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UpdateEmployee extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
	///			try {
	//				UpdateEmployee frame = new UpdateEmployee();
	//				frame.setVisible(true);
	//			} catch (Exception e) {
	//				e.printStackTrace();
	//			}
	//		}
	//	});
//	}

	/**
	 * Create the frame.
	 */
	public UpdateEmployee() {
		
		setBounds(100, 100, 875, 429);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblupdateAnEmployee = new JLabel("\"UPDATE AN EMPLOYEE\"");
		lblupdateAnEmployee.setFont(new Font("SimSun", Font.BOLD, 19));
		lblupdateAnEmployee.setBounds(289, 11, 274, 72);
		contentPane.add(lblupdateAnEmployee);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(205, 133, 63));
		panel.setBounds(37, 79, 786, 257);
		contentPane.add(panel);
		
		JButton btnUpdateTheEmployee = new JButton("UPDATE THE EMPLOYEE NAME");
		btnUpdateTheEmployee.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				EmNameUp frame = new EmNameUp();
				frame.setVisible(true);
			}
		});
		btnUpdateTheEmployee.setBounds(114, 89, 209, 23);
		panel.add(btnUpdateTheEmployee);
		
		JButton btnUpdateEmployeeNumber = new JButton("UPDATE EMPLOYEE NUMBER");
		btnUpdateEmployeeNumber.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				EmNumberUp frame = new EmNumberUp();
				frame.setVisible(true);
			}
		});
		btnUpdateEmployeeNumber.setBounds(114, 147, 209, 23);
		panel.add(btnUpdateEmployeeNumber);
		
		JButton btnUpdateEmployeeAddress = new JButton("UPDATE EMPLOYEE ADDRESS");
		btnUpdateEmployeeAddress.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				EmAddressUP frame = new EmAddressUP();
				frame.setVisible(true);
			}
		});
		btnUpdateEmployeeAddress.setBounds(395, 89, 229, 23);
		panel.add(btnUpdateEmployeeAddress);
		
		JButton btnUpdateEmployeeEmail = new JButton("UPDATE EMPLOYEE EMAIL");
		btnUpdateEmployeeEmail.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				EmEmailUp frame = new EmEmailUp();
				frame.setVisible(true);
			}
		});
		btnUpdateEmployeeEmail.setBounds(395, 147, 229, 23);
		panel.add(btnUpdateEmployeeEmail);
		
		JLabel label = new JLabel("CHOOSE WHAT TO UPDATE");
		label.setFont(new Font("Microsoft YaHei UI Light", Font.BOLD, 16));
		label.setBounds(251, 11, 247, 72);
		panel.add(label);
	}
}
