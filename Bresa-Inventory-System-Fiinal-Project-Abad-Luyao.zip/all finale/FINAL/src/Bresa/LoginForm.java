package Bresa;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class LoginForm extends JFrame {

	
	/**
	 * 
	 */
	
	private JPanel contentPane;
	private JTextField user;
	private JPasswordField pass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginForm frame = new LoginForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginForm() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 422, 290);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(205, 133, 63));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("Bresa Drug Store Inventory System");
		label.setFont(new Font("SimSun", Font.BOLD, 20));
		label.setBounds(16, 19, 380, 37);
		contentPane.add(label);
		
		user = new JTextField();
		user.setColumns(10);
		user.setBounds(147, 92, 122, 20);
		contentPane.add(user);
		
		
		JLabel user1 = new JLabel("Username");
		user1.setFont(new Font("Tahoma", Font.BOLD, 12));
		user1.setBounds(176, 67, 93, 14);
		contentPane.add(user1);
		
		JLabel pass1 = new JLabel("Password");
		pass1.setFont(new Font("Tahoma", Font.BOLD, 12));
		pass1.setBounds(176, 125, 93, 14);
		contentPane.add(pass1);
		
		pass = new JPasswordField();
		pass.setBounds(147, 147, 122, 20);
		contentPane.add(pass);
		
		JButton button = new JButton("LOGIN\r\n");
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/login2","root","boboka");
					Statement stat= conn.createStatement();
					String sql="Select *from user_account where Username='" + user.getText() + "' and Password='"+pass.getText().toString()+"'";
					ResultSet rs = stat.executeQuery(sql);
					
					if(rs.next()) {
						JOptionPane.showMessageDialog(null, "Login Successfull");
						
						MainFrame frame = new MainFrame();
						frame.setVisible(true);
						dispose();
						
					}
					else { 
						JOptionPane.showMessageDialog(null, "Wrong Username and Password");
					conn.close();
					}
					
				}
				catch(Exception e) {
					System.out.println(e);
				 
				
					
				}
				
			}
			
		});
		button.setBounds(147, 199, 122, 23);
		contentPane.add(button);
	}

}
